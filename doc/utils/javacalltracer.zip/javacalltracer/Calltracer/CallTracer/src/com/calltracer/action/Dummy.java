/*
 * Copyright 2009 Syed Ali Jafar Naqvi
 * 
 * This file is part of Java Call Tracer.
 *
 * Java Call Tracer is free software: you can redistribute it and/or modify
 * it under the terms of the Lesser GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Java Call Tracer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Lesser GNU General Public License for more details.
 *
 * You should have received a copy of the Lesser GNU General Public License
 * along with Java Call Tracer.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.calltracer.action;

public class Dummy {
	private String name;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Dummy() {
		// TODO Auto-generated constructor stub
	}

	public Dummy(String name) {
		this.setName(name);
	}

	public void run() {
		if(this.getName().equals("t1")) {
			x();
		} else {
			y();
		}
	}

	private void x() {
		System.out.println("This is x");
	}

	private void y() {
		System.out.println("This is y");
	}
}
