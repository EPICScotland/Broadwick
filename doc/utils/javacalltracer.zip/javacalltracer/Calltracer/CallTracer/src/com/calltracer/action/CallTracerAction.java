/*
 * Copyright 2009 Syed Ali Jafar Naqvi
 * 
 * This file is part of Java Call Tracer.
 *
 * Java Call Tracer is free software: you can redistribute it and/or modify
 * it under the terms of the Lesser GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Java Call Tracer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Lesser GNU General Public License for more details.
 *
 * You should have received a copy of the Lesser GNU General Public License
 * along with Java Call Tracer.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.calltracer.action;

import java.io.File;
import java.io.FileReader;

import org.apache.struts.action.Action;

import com.calltracer.form.CallTracerForm;
import com.calltracer.jni.CallTracerJNI;

public class CallTracerAction extends Action {
	public org.apache.struts.action.ActionForward execute(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws Exception {
	    CallTracerForm codeAnalyzerForm = (CallTracerForm) form;
		System.out.println("Doing action :" + codeAnalyzerForm.getAction());
		if("Start".equalsIgnoreCase(codeAnalyzerForm.getAction())) {
			(new CallTracerJNI()).start();
		} else if ("Stop".equalsIgnoreCase(codeAnalyzerForm.getAction())){
			(new CallTracerJNI()).stop();
        } else if ("Print Trace".equalsIgnoreCase(codeAnalyzerForm.getAction())){
            String traceFile = (new CallTracerJNI()).printTrace();
            File file = new File(traceFile);
            FileReader fileReader = new FileReader(file);
            char[] trace = new char[1];
            String traceStr = "";
            while(fileReader.read(trace, 0, 1) != -1) {
                traceStr = traceStr + trace[0];
            }
            codeAnalyzerForm.setTrace(traceStr);
        } else if ("Flush".equalsIgnoreCase(codeAnalyzerForm.getAction())){
            (new CallTracerJNI()).flush();
		} else {
			new Dummy("t1").run();
		}
		return mapping.findForward("success");
	}
}
