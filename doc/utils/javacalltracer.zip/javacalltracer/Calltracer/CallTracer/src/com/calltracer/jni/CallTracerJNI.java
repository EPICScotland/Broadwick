/*
 * Copyright 2009 Syed Ali Jafar Naqvi
 * 
 * This file is part of Java Call Tracer.
 *
 * Java Call Tracer is free software: you can redistribute it and/or modify
 * it under the terms of the Lesser GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Java Call Tracer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Lesser GNU General Public License for more details.
 *
 * You should have received a copy of the Lesser GNU General Public License
 * along with Java Call Tracer.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.calltracer.jni;

public class CallTracerJNI {
	//Native method declaration
	  public native void start();
	  public native void stop();
      public native String printTrace();
      public native void flush();
	//Load the library
	  static {
	    System.loadLibrary(System.getProperty("calltracerlib"));
	  }
}
