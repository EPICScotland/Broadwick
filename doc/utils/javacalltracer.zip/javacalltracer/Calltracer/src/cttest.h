/*
 * Copyright 2009 Syed Ali Jafar Naqvi
 *
 * This file is part of Java Call Tracer.
 *
 * Java Call Tracer is free software: you can redistribute it and/or modify
 * it under the terms of the Lesser GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Java Call Tracer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Lesser GNU General Public License for more details.
 *
 * You should have received a copy of the Lesser GNU General Public License
 * along with Java Call Tracer.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <malloc.h>
#include <string.h>
#if defined TEST_MYTRACE
typedef int methodIdType;
typedef int* classIdType;
typedef int* threadIdType;
typedef int JNIEnv;

typedef struct methodType {
    char *method_name;
    char *method_signature;
    int start_lineno;
    int end_lineno;
    int method_id;
} methodType;

typedef struct Monitor {
	char *name;
} Monitor;

typedef Monitor *monitorType;

monitorType monitor_lock;

monitorType createMonitor(char *name) {
	monitorType mon = (monitorType) malloc(sizeof(monitorType));
	mon->name = strdup(name);
	return mon;
}

void getMonitor(monitorType monitor) {
}

void releaseMonitor(monitorType monitor) {
}

void destroyMonitor(monitorType monitor) {
	free(monitor);
}

void delay(int i) {
}

int one = 1;
int two = 2;
int three = 3;
int none = -1;
int t1 = 1;
int t2 = 2;

/*Dummy method*/
classIdType getMethodClass(methodIdType methodId) {

	switch(methodId) {
		case 1: return &one;
		case 2: return &one;
		case 3: return &one;
		case 4: return &two;
		case 5: return &two;
		case 6: return &three;
		case 7: return &three;
		case 8: return &three;
	}
	return &none;
}

int isSameThread(JNIEnv *jni_env, threadIdType threadId1, threadIdType threadId2) {
	return (threadId1 == threadId2);
}

int isSameClass(JNIEnv *jni_env, classIdType classId1, classIdType classId2) {
	return (classId1 == classId2);
}

threadIdType getThreadRef(JNIEnv *jni_env, threadIdType threadId) {
	return threadId;
}

classIdType getClassRef(JNIEnv *jni_env, classIdType classId) {
	return classId;
}

#include "ctcom.h"
#endif
