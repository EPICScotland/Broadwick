/*
 * Copyright 2009 Syed Ali Jafar Naqvi
 *
 * This file is part of Java Call Tracer.
 *
 * Java Call Tracer is free software: you can redistribute it and/or modify
 * it under the terms of the Lesser GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Java Call Tracer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Lesser GNU General Public License for more details.
 *
 * You should have received a copy of the Lesser GNU General Public License
 * along with Java Call Tracer.  If not, see <http://www.gnu.org/licenses/>.
 */

#if defined JVMPI_TYPE
#include <jvmpi.h>
#include <jni.h>
#include "ctjni.h"

typedef jmethodID methodIdType;
typedef jobjectID classIdType;
typedef JNIEnv *threadIdType;
typedef JVMPI_RawMonitor monitorType;
typedef JVMPI_Method methodType;

monitorType monitor_lock;

#define strdup _strdup

static JVMPI_Interface *jvmpi_interface;

monitorType createMonitor(char *name) {
	return jvmpi_interface->RawMonitorCreate(name);
}

void getMonitor(monitorType monitor) {
	jvmpi_interface->RawMonitorEnter(monitor);
}

void releaseMonitor(monitorType monitor) {
	jvmpi_interface->RawMonitorExit(monitor);
}

void destroyMonitor(monitorType monitor) {
	jvmpi_interface->RawMonitorDestroy(monitor);
}

void delay(int i) {
	i *= 100;
	for(; i > 0; i --) {
		__asm ("pause");
	}
}

classIdType getMethodClass(methodIdType methodId) {
	return jvmpi_interface->GetMethodClass(methodId);
}

bool isSameThread(JNIEnv* jni_env, threadIdType threadId1, threadIdType threadId2) {
	return (threadId1 == threadId2);
}

bool isSameClass(JNIEnv* jni_env, classIdType classId1, classIdType classId2) {
	return (classId1 == classId2);
}

threadIdType getThreadRef(JNIEnv* jni_env, threadIdType threadId) {
	return threadId;
}

classIdType getClassRef(JNIEnv* jni_env, classIdType classId) {
	return classId;
}

#include "ctcom.h"

void notifyEvent(JVMPI_Event *event) {
	switch(event->event_type) {
		case JVMPI_EVENT_METHOD_ENTRY:
			newMethodCall(event->u.method.method_id, event->env_id, event->env_id);
			break;
		case JVMPI_EVENT_METHOD_EXIT:
			endCall(event->u.method.method_id, event->env_id, event->env_id);
			break;
		case JVMPI_EVENT_CLASS_LOAD:
			newClass(event->u.class_load.class_id, event->u.class_load.class_name, event->u.class_load.num_methods, event->u.class_load.methods, event->env_id);
			break;
		case JVMPI_EVENT_CLASS_UNLOAD:
			freeClassId(event->u.class_unload.class_id, event->env_id);
			break;
		case JVMPI_EVENT_THREAD_END:
			break;
		case JVMPI_EVENT_JVM_SHUT_DOWN:
			printFullTrace(event->env_id);
			releaseFullTrace(event->env_id);
			freeAllClasses();
			destroyMonitor(monitor_lock);
			clearAllFilters();
			break;
	}
}

JNIEXPORT void JNICALL Java_com_calltracer_jni_CallTracerJNI_start (JNIEnv *jni_env, jobject obj) {
	jvmpi_interface->EnableEvent(JVMPI_EVENT_METHOD_ENTRY, NULL);
	jvmpi_interface->EnableEvent(JVMPI_EVENT_METHOD_EXIT, NULL);
	jvmpi_interface->EnableEvent(JVMPI_EVENT_JVM_SHUT_DOWN, NULL);
	jvmpi_interface->EnableEvent(JVMPI_EVENT_THREAD_END, NULL);
}

JNIEXPORT void JNICALL Java_com_calltracer_jni_CallTracerJNI_stop (JNIEnv *jni_env, jobject obj) {
	jvmpi_interface->DisableEvent(JVMPI_EVENT_METHOD_ENTRY, NULL);
	jvmpi_interface->DisableEvent(JVMPI_EVENT_METHOD_EXIT, NULL);
	jvmpi_interface->DisableEvent(JVMPI_EVENT_THREAD_END, NULL);
}

JNIEXPORT jstring JNICALL Java_com_calltracer_jni_CallTracerJNI_printTrace (JNIEnv *jni_env, jobject obj) {
	printFullTrace(jni_env);
	return jni_env->NewStringUTF(traceFile);
}

JNIEXPORT void JNICALL Java_com_calltracer_jni_CallTracerJNI_flush (JNIEnv *jni_env, jobject obj) {
	releaseFullTrace(jni_env);
}

#endif
