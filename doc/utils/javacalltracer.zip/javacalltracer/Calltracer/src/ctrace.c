/*
 * Copyright 2009 Syed Ali Jafar Naqvi
 *
 * This file is part of Java Call Tracer.
 *
 * Java Call Tracer is free software: you can redistribute it and/or modify
 * it under the terms of the Lesser GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Java Call Tracer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Lesser GNU General Public License for more details.
 *
 * You should have received a copy of the Lesser GNU General Public License
 * along with Java Call Tracer.  If not, see <http://www.gnu.org/licenses/>.
 */

/*#define JVMPI_TYPE*/
/*#define TEST_MYTRACE*/
/*#define JVMTI_TYPE*/
#define _CRT_SECURE_NO_DEPRECATE

#if defined TEST_MYTRACE
#include "cttest.h"
int main(int argc, char *argv[]) {
	methodType method1[3];
	methodType method2[2];
	JNIEnv x;
	JNIEnv *jni_env;
	jni_env = &x;
	char *fileName;

	char testO[500];
	if(argv[1] != NULL) {
		fileName = argv[1];
	} else {
		fileName = "C:\\calltracer\\test.txt";
	}
	sprintf(testO, "%s%s%s%c", "traceFile=", fileName, ",filterList=com.test.TestClass,outputType=xml", '\0');
//	sprintf(testO, "%s%s%c", "traceFile=", fileName, '\0');
//	sprintf(testO, "%s%c", "usage,filterList=Lcom/test/TestClass", '\0');
//	sprintf(testO, "%s%c", "", '\0');
	setup(testO);

	method1[0].method_name = "test1";
	method1[0].method_signature = "([Ljava/lang/String;I)I";
	method1[0].start_lineno = 1;
	method1[0].end_lineno = 10;
	method1[0].method_id = 1;

	method1[1].method_name = "test2";
	method1[1].method_signature = "([Ljava/lang/String;Lcom/test/TestClass)V";
	method1[1].start_lineno = 1;
	method1[1].end_lineno = 10;
	method1[1].method_id = 2;

	method1[2].method_name = "test3";
	method1[2].method_signature = "([Ljava/lang/String;C)D";
	method1[2].start_lineno = 1;
	method1[2].end_lineno = 10;
	method1[2].method_id = 3;

	method2[0].method_name = "test4";
	method2[0].method_signature = "([Ljava/lang/String;S)C";
	method2[0].start_lineno = 1;
	method2[0].end_lineno = 10;
	method2[0].method_id = 4;

	method2[1].method_name = "test5";
	method2[1].method_signature = "(II[Ljava/lang/String;)Lcom/test/TestClass";
	method2[1].start_lineno = 1;
	method2[1].end_lineno = 10;
	method2[1].method_id = 5;

	newClass(&one, "Lcom/test/TestClass;", 3, &(method1[0]), jni_env);
	newClass(&two, "Lcom/test/TestClass1;", 2, &(method2[0]), jni_env);
	newMethodCall(1, &t1, jni_env);
	newMethodCall(2, &t1, jni_env);
	newMethodCall(5, &t1, jni_env);
	endCall(5, &t1, jni_env);

	newMethodCall(5, &t2, jni_env);
	newMethodCall(2, &t2, jni_env);
	newMethodCall(1, &t2, jni_env);
	endCall(1, &t2, jni_env);

	endCall(2, &t1, jni_env);
	newMethodCall(4, &t1, jni_env);
	endCall(4, &t1, jni_env);
	newMethodCall(4, &t1, jni_env);
	endCall(4, &t1, jni_env);
	newMethodCall(4, &t1, jni_env);
	endCall(4, &t1, jni_env);
	endCall(1, &t1, jni_env);

	endCall(2, &t2, jni_env);

	freeClassId(&one, jni_env);

	method1[0].method_id = 6;
	method1[1].method_id = 7;
	method1[2].method_id = 8;

	newClass(&three, "Lcom/test/TestClass3;", 3, &(method1[0]), jni_env);

	newMethodCall(8, &t2, jni_env);
	newMethodCall(4, &t2, jni_env);
	newMethodCall(7, &t2, jni_env);
	endCall(7, &t2, jni_env);
	endCall(4, &t2, jni_env);
	endCall(8, &t2, jni_env);
	endCall(5, &t2, jni_env);

	printFullTrace(jni_env);
	releaseFullTrace(jni_env);
	freeAllClasses();
	destroyMonitor(monitor_lock);
	clearAllFilters();
	return 0;
}

#elif defined JVMPI_TYPE
#include "ctjpi.h"
extern "C" {
	JNIEXPORT jint JNICALL JVM_OnLoad(JavaVM *jvm, char *options, void *reserved) {
		// get jvmpi interface pointer
		if ((jvm->GetEnv((void **)&jvmpi_interface, JVMPI_VERSION_1)) < 0) {
			fprintf(stderr, "call tracer> error in obtaining jvmpi interface pointer\n");
			return JNI_ERR;
		}

		// initialize jvmpi interface
		jvmpi_interface->NotifyEvent = notifyEvent;
		jvmpi_interface->EnableEvent(JVMPI_EVENT_CLASS_LOAD, NULL);
		jvmpi_interface->EnableEvent(JVMPI_EVENT_CLASS_UNLOAD, NULL);

		setup(options);
		if(strcmp(usage, "uncontrolled") == 0) {
			jvmpi_interface->EnableEvent(JVMPI_EVENT_METHOD_ENTRY, NULL);
			jvmpi_interface->EnableEvent(JVMPI_EVENT_METHOD_EXIT, NULL);
			jvmpi_interface->EnableEvent(JVMPI_EVENT_JVM_SHUT_DOWN, NULL);
			jvmpi_interface->EnableEvent(JVMPI_EVENT_THREAD_END, NULL);
		}

		return JNI_OK;
 	}
}

#elif defined JVMTI_TYPE
#include "ctjti.h"
JNIEXPORT jint JNICALL Agent_OnLoad(JavaVM *vm, char *options, void *reserved) {
	jint rc;
	jvmtiCapabilities capabilities;
	jvmtiEventCallbacks callbacks;
	jvmtiEnv *jvmti;

	rc = vm->GetEnv((void **)&jvmti, JVMTI_VERSION);
	if (rc != JNI_OK) {
		fprintf(stderr, "ERROR: Unable to create jvmtiEnv, GetEnv failed, error=%d\n", rc);
		return -1;
	}
	jvmti->GetCapabilities(&capabilities);
	capabilities.can_generate_method_entry_events = 1;
	capabilities.can_generate_method_exit_events = 1;

	jvmti->AddCapabilities(&capabilities);

	memset(&callbacks, 0, sizeof(callbacks));
	callbacks.VMDeath = &vmDeath;
	callbacks.ThreadStart = &threadStart;
	callbacks.ThreadEnd = &threadEnd;
	callbacks.MethodEntry = &methodEntry;
	callbacks.MethodExit = &methodExit;

	jvmti->SetEventCallbacks(&callbacks, sizeof(callbacks));
	jvmti->SetEventNotificationMode(JVMTI_DISABLE, JVMTI_EVENT_CLASS_PREPARE, NULL);

	g_jvmti_env = jvmti;

	setup(options);

	if(strcmp(usage, "uncontrolled") == 0) {
		jvmti->SetEventNotificationMode(JVMTI_ENABLE, JVMTI_EVENT_VM_DEATH, NULL);
		jvmti->SetEventNotificationMode(JVMTI_ENABLE, JVMTI_EVENT_THREAD_START, NULL);
		jvmti->SetEventNotificationMode(JVMTI_ENABLE, JVMTI_EVENT_THREAD_END, NULL);
		jvmti->SetEventNotificationMode(JVMTI_ENABLE, JVMTI_EVENT_METHOD_ENTRY, NULL);
		jvmti->SetEventNotificationMode(JVMTI_ENABLE, JVMTI_EVENT_METHOD_EXIT, NULL);
	}

	return JNI_OK;
}
#endif
